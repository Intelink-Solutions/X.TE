<?php

namespace App\Notifications;

use App\Models\FeedPost;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;

class NewFeedPostNotification extends Notification
{
    use Queueable;

    public function __construct(public FeedPost $post) {}

    public function via(object $notifiable): array
    {
        return ['database'];
    }

    public function toArray(object $notifiable): array
    {
        return [
            'type' => 'new_feed_post',
            'title' => $this->post->title ?: "New {$this->post->category} post",
            'message' => "{$this->post->author} posted: ".str($this->post->text)->squish()->limit(130),
            'url' => '/news-feed#post-'.$this->post->id,
            'entity_id' => $this->post->id,
            'image_url' => $this->post->image_url,
            'icon' => $this->post->kind,
        ];
    }
}
